﻿using System.Collections.Concurrent;
using System.Diagnostics.CodeAnalysis;

class semana15_actividad1
{
    static void Main()
    {
        estudiante estudiante1=new estudiante();
        System.Console.WriteLine("INGRESE NOMBRE DEL ESTUDIANTE"); string nombre=Console.ReadLine();
        System.Console.WriteLine("INGRESE EDAD DELESTUDIANTE"); int edad_Estudiente=int.Parse(Console.ReadLine());
        System.Console.WriteLine("INGRESE CARRERA DEL ESTUDIANTE"); string nombre_Carrera=Console.ReadLine();
        System.Console.WriteLine("INGRESE NOTA DEL ESTUDIANTE"); double nota_Estudiante=double.Parse(Console.ReadLine());
        System.Console.WriteLine("INGRESE CARNET DEL ESTUDIANTE"); string numero_Carnet=Console.ReadLine();
        estudiante1.Name=nombre;
        estudiante1.Edad=edad_Estudiente;
        estudiante1.Carrera=nombre_Carrera;
        estudiante1.Carnet=numero_Carnet;
        estudiante1.Nota_Admision=nota_Estudiante;
        estudiante1.mostrar_resumen();
        if (estudiante1.puede_matricular())
        {
            System.Console.WriteLine("PUEDE MATRICULARSE");
        }else
        {
            System.Console.WriteLine("NO PUEDE MATRICULARSE");
        }
        
    }
    public class estudiante()
    {
        public string Name{ get; set;}
        public int Edad{ get; set;}
        public string Carrera{ get; set;}
        public string Carnet{ get; set;}
        public double Nota_Admision{ get; set;}

        public void mostrar_resumen()
        {
            System.Console.WriteLine(Name+" "+Edad+" "+Carrera+" "+Carnet+" "+Nota_Admision);
        }
        public bool puede_matricular()
        {
            bool terminaCon = Carnet.EndsWith("2025");
                if ((Nota_Admision>=75)&&(terminaCon==true))
                {
                        return true;
                }else
                {
                        return false;
                }
        }
    }   
}   