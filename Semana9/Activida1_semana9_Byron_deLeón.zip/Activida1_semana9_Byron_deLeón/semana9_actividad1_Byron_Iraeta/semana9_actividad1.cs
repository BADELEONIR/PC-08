﻿using System.Collections;
using System.ComponentModel;
using System.Runtime.InteropServices;

class semana9_actividad1()
{
    static void Main()
    {   System.Console.WriteLine("VERIFICACION DE NUMERO PRIMO");
        System.Console.WriteLine();
        int numero;
        while (true)
            {
                string entrada;
                
            Console.Write($"INGRESE UN NUMERO ENTERO: ");
            entrada = Console.ReadLine();
 
            if (int.TryParse(entrada, out numero))
            {
                break;
            }
            else
            {
                Console.Write($"Entrada inválida!!!!");
            }
            }
        while (true)
            {
        
            if ((numero>=1)&&(numero<=999999))
            {   
                break;
            }
            else
            {   System.Console.Write($"DEBE SER MAYOR A CERO Y NO POSEER MÁS DE 6 CIFRAS, INGRESE NUEVAMENTE EL NUMERO: ");
                numero=int.Parse(Console.ReadLine());
                
                
            }
            }
            System.Console.WriteLine();
            System.Console.WriteLine(verificacion(numero));
             


    }
static string verificacion(int numero)
{   int cantidad=0;
    int residuo;
    string resultado;
    for(int i=1;i <=numero;i++)
    {
        residuo=numero % i;
        if (residuo==0)
        {
                cantidad=cantidad+1;
        }
    }
    if (cantidad<=2)
    {
        resultado="ES UN NUMERO PRIMO";
    }else
    {
        resultado="NO ES UN NUMERO PRIMO";
    }
    return resultado;
}

}
