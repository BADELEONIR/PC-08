﻿using System.Runtime.CompilerServices;

class Acitividad1_Semana18
{   
    static void Main()
    {   char desicionMenu='s';
        InformacionUSuarios informacionUSuariosNo1=new InformacionUSuarios();
        informacionUSuariosNo1.guardarInformacion();
        while (desicionMenu!='4')
        {
            System.Console.WriteLine("1. Mostrar nombre y notas aprobadas");
            System.Console.WriteLine("2. Mostrar nombre y notas reprobadas");
            System.Console.WriteLine("3. Mostrar promedi odel grupo");
            System.Console.WriteLine("4. Salir");
            System.Console.Write("INGRESE OPCION A REALIZAR: ");
            desicionMenu=char.Parse(Console.ReadLine());
            System.Console.WriteLine();          
            if (desicionMenu=='1')
            {
                informacionUSuariosNo1.notasAprobadas();
            }else if (desicionMenu=='2')
            {
                informacionUSuariosNo1.notasDesaprobadas();
            }else if (desicionMenu=='3')
            {
                System.Console.WriteLine("EL PROMEDIO DE NOTAS DEL GRUPO ES: "+informacionUSuariosNo1.promedioGrupo());
            }
        }
             
    }
    public class InformacionUSuarios
    {   double promedioAlumno=0, notas;
        public static string[,] datosAlumnos=new string[10,11];
        public void guardarInformacion()
        {
            for (int i=0;i<10;i++)
            {
                System.Console.WriteLine("INGRESE NOMBRE DEL ESTUIDANTE "+(i+1));  datosAlumnos[i,0]=Console.ReadLine();
                for(int i2=1;i2<11;i2++)
                {
                    System.Console.WriteLine("INGRESE NOTA "+i2); datosAlumnos[i,i2]=Console.ReadLine();
                }

            }
            
        }

        public void mostrarDatos()
        {
            for (int i=0;i<10;i++)
            {
                for (int i2=0;i2<11;i2++)
                {
                    Console.Write(datosAlumnos[i,i2]+" ");
                }
                System.Console.WriteLine();
            }
        }
        public void notasAprobadas()
        {
            for (int i=0;i<10;i++)
            {   
                notas=0;
                for (int i2=1;i2<11;i2++)
                {
                    if (double.Parse(datosAlumnos[i,i2])>=65)
                    {
                        notas++;
                    }
                }
                System.Console.WriteLine("EL ALUMNO "+datosAlumnos[i,0]+" APROBO "+notas+" CURSOS");
            }            
        }

        public void notasDesaprobadas()
        {
            for (int i=0;i<10;i++)
            {   
                notas=0;
                for (int i2=1;i2<11;i2++)
                {
                    if (double.Parse(datosAlumnos[i,i2])<=65)
                    {
                        notas++;
                    }
                }
                System.Console.WriteLine("EL ALUMNO "+datosAlumnos[i,0]+" REPROBO "+notas+" CURSOS");
            }            
        }

        public double promedioGrupo()
        {
            for (int i=0;i<10;i++)
            {               
                for (int i2=1;i2<11;i2++)
                {
                    promedioAlumno=double.Parse(datosAlumnos[i,i2])+promedioAlumno;                
                }
                
            }     
            promedioAlumno=promedioAlumno/100;
            return promedioAlumno;
        }


    }
}